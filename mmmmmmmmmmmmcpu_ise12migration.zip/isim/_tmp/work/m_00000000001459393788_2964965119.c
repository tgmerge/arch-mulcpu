/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                         */
/*  \   \        Copyright (c) 2003-2007 Xilinx, Inc.                 */
/*  /   /        All Right Reserved.                                  */
/* /---/   /\                                                         */
/* \   \  /  \                                                        */
/*  \___\/\___\                                                       */
/**********************************************************************/

/* This file is designed for use with ISim build 0x42e8db27 */

#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/media/5AF46725F467029D/mmmmmmmmmmmmcpu/clock.v";
static int ng1[] = {1, 0};
static int ng2[] = {0, 0};



static void A8_0(char *t0)
{
    char t7[8];
    char t16[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t8;
    char *t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    char *t30;

LAB0:    t1 = (t0 + 1432U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(8, ng0);
    t2 = (t0 + 1596);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(9, ng0);

LAB5:    xsi_set_current_line(10, ng0);
    t3 = (t0 + 968);
    t4 = (t3 + 32U);
    t5 = *((char **)t4);
    t6 = ((char*)((ng1)));
    memset(t7, 0, 8);
    xsi_vlog_unsigned_add(t7, 32, t5, 32, t6, 32);
    t8 = (t0 + 968);
    xsi_vlogvar_assign_value(t8, t7, 0, 0, 32);
    xsi_set_current_line(11, ng0);
    t2 = (t0 + 968);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t0 + 652U);
    t6 = *((char **)t5);
    memset(t7, 0, 8);
    t5 = (t7 + 4U);
    t8 = (t4 + 4U);
    t9 = (t6 + 4U);
    if (*((unsigned int *)t8) != 0)
        goto LAB7;

LAB6:    if (*((unsigned int *)t9) != 0)
        goto LAB7;

LAB10:    if (*((unsigned int *)t4) < *((unsigned int *)t6))
        goto LAB9;

LAB8:    *((unsigned int *)t7) = 1;

LAB9:    t10 = (t7 + 4U);
    t11 = *((unsigned int *)t10);
    t12 = (~(t11));
    t13 = *((unsigned int *)t7);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB11;

LAB12:
LAB13:    goto LAB2;

LAB7:    *((unsigned int *)t7) = 1;
    *((unsigned int *)t5) = 1;
    goto LAB9;

LAB11:    xsi_set_current_line(12, ng0);

LAB14:    xsi_set_current_line(13, ng0);
    t17 = (t0 + 876);
    t18 = (t17 + 32U);
    t19 = *((char **)t18);
    memset(t16, 0, 8);
    t20 = (t16 + 4U);
    t21 = (t19 + 4U);
    t22 = *((unsigned int *)t19);
    t23 = (~(t22));
    *((unsigned int *)t16) = t23;
    *((unsigned int *)t20) = 0;
    if (*((unsigned int *)t21) != 0)
        goto LAB16;

LAB15:    t28 = *((unsigned int *)t16);
    *((unsigned int *)t16) = (t28 & 1U);
    t29 = *((unsigned int *)t20);
    *((unsigned int *)t20) = (t29 & 1U);
    t30 = (t0 + 876);
    xsi_vlogvar_assign_value(t30, t16, 0, 0, 1);
    xsi_set_current_line(14, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 968);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);
    goto LAB13;

LAB16:    t24 = *((unsigned int *)t16);
    t25 = *((unsigned int *)t21);
    *((unsigned int *)t16) = (t24 | t25);
    t26 = *((unsigned int *)t20);
    t27 = *((unsigned int *)t21);
    *((unsigned int *)t20) = (t26 | t27);
    goto LAB15;

}


extern void work_m_00000000001459393788_2964965119_init()
{
	static char *pe[] = {(void *)A8_0};
	xsi_register_didat("work_m_00000000001459393788_2964965119", "isim/_tmp/work/m_00000000001459393788_2964965119.didat");
	xsi_register_executes(pe);
}
